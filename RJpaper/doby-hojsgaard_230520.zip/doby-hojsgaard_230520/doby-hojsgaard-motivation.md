Motivating letter for the paper

"The doBy package for data handling, linear estimates and LS-means"

by Søren Højsgaard

The virtue of the package is the simplicity: It mainly is a thin layer
of functionality on top of well known and established data structures.
The doBy package has existed on CRAN since 2006. Despite the
availability of other packages with similar functionality (e.g. the
tidyverse eco system and the data.table package), the doBy package has
a substantial user group.


